package user_interface.search_interface;

import java.util.EventListener;
import Class_Framework.*;

public interface SearchFormListener extends EventListener{
	public void formEventOccurred(SearchFormEvent event);

}
