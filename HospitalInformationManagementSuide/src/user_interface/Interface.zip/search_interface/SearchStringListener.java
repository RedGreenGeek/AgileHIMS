package user_interface.search_interface;

public interface SearchStringListener {
	public void textEmitted(String text);
}
