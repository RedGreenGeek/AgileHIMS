package user_interface.staff_interface;

import java.util.EventListener;
import Class_Framework.*;

public interface StaffFormListener extends EventListener{
	public void formEventOccurred(StaffFormEvent event);

}
