package user_interface.staff_interface;

public interface StaffStringListener {
	public void textEmitted(String text);
}
