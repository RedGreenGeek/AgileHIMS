package user_interface.patient_interface;

public interface PatientStringListener {
	public void textEmitted(String text);
}
